# FRALGO

**FRALGO** (prononcé *efferalgo*) est un interpréteur pour le pseudo-langage de programmation **Algo**.
