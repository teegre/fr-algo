# PLY package
# Author: David Beazley (dave@dabeaz.com)
# https://github.com/dabeaz/ply

__version__ = '2022.10.27'
